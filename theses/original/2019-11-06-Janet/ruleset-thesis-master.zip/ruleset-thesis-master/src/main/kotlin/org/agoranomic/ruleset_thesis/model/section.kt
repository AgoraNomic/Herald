package org.agoranomic.ruleset_thesis.model

data class Section(val title: String, val description: String, val rules: List<Rule>)
