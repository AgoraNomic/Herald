# Rule Dependents

Lists of dependents of various interesting rules are included:
 - [Rule 2152](dependents_2152.txt)
 - [Rule 869](dependents_869.txt)
 - [Rule 1023](dependents_1023.txt)
 - [Rule 478](dependents_478.txt)
